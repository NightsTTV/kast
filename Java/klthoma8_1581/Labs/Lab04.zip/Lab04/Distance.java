import java.util.Scanner;
	
public class Distance {
	static Scanner input = new Scanner(System.in);
	
	

	public static void main(String[] args) {
		int testCase = input.nextInt();
		input.nextLine();

	
		for (int t = 0; t < testCase; t++) {
			String inputLine = input.nextLine();

			String [] coordinates = inputLine.split(" ");
			double x1 = Double.parseDouble(coordinates[0]);
			double y1 = Double.parseDouble(coordinates[1]);
			double x2 = Double.parseDouble(coordinates[2]);
			double y2 = Double.parseDouble(coordinates[3]);
			double result = distance(x1, y1, x2, y2);

			System.out.println(result);
		}
	}

		public static double distance(double x1, double y1, double x2, double y2){
			double xrate = (x2 - x1);
			double yrate = (y2 - y1);
			double xSqrd = Math.pow(xrate, 2);
			double ySqrd = Math.pow(yrate, 2);
			return(Math.sqrt(xSqrd+ySqrd));
		}

	}

