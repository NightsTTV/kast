public class Time {

			public static double secondsToMinutes(int seconds){
				return (seconds / 60.0);
			}
			public static double secondsToHours(int seconds) {
				return(seconds/3600.0);
			}
			public static double secondsToDays(int seconds) {
				return(seconds/86400.0);
			}
			public static double secondsToYears(int seconds) {
				return(seconds/ 31_536_000.0);
			}
			public static double minutesToSeconds(double minutes) {
				return(minutes*60);
			}
			public static double hoursToSeconds(double hours) {
				return(hours * 3600);
			}
			public static double daysToSeconds(double days) {
				return(days * 86400);
			}
			public static double yearsToSeconds(double years) {
				return((((years*60)*60)*24)*365);
			}
}